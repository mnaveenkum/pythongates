def gen_roll(n1,n2):
    for i in range(n1,n2+1):
        print("17F21A0"+str(i))